This is a minimal example of a book based on R Markdown and **bookdown** (https://github.com/rstudio/bookdown). Please see the page "Get Started" at https://bookdown.org/ for how to compile this example.

You can find the preview of this example at https://bookdown.org/yihui/bookdown-demo/
